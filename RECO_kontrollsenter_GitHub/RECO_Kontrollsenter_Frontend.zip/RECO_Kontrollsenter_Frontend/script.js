function startDemo() {
    alert("Demo-prosjektet er aktivert!");
}
function downloadPackage() {
    window.location.href = "RECO_Demopakke.zip";
}
function startVideo() {
    alert("Opplæringsvideo starter...");
}
function goToModules() {
    alert("Navigerer til kalkylemoduler...");
}
